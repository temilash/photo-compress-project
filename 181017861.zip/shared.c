#include "images.h"
#include "shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define BAD_ARGS 1
#define BAD_FILE 2
#define BAD_MAGIC_NUMBER 3
#define BAD_DIM 4
#define BAD_MALLOC 5
#define BAD_DATA 6
#define BAD_OUTPUT 7
#define MAGIC_NUMBER 0x6265
#define MAGIC_NUMBEREBU 0x7565
#define MAGIC_NUMBEREBC 0x6365
#define MAX_DIMENSION 262144
#define MIN_DIMENSION 1
#define SKIP 411
#define DIFFERENT 222

int validate_args(int argc, const char *filename)
{
    if (argc != 3)
    {
        if (argc == 1)
        { // if arguments are 1 then print one of options available depending on the type of file
            if (strcmp(filename, "./ebfComp") == 0)
            {
                printf("Usage: ebfComp file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebuComp") == 0)
            {
                printf("Usage: ebuComp file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebuEcho") == 0)
            {
                printf("Usage: ebuEcho file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebfEcho") == 0)
            {
                printf("Usage: ebfEcho file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebf2ebu") == 0)
            {
                printf("Usage: ebf2ebu file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebu2ebf") == 0)
            {
                printf("Usage: ebu2ebf file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcComp") == 0)
            {
                printf("Usage: ebcComp file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebc2ebu") == 0)
            {
                printf("Usage: ebc2ebu file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebu2ebc") == 0)
            {
                printf("Usage: ebu2ebc file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcEcho") == 0)
            {
                printf("Usage: ebcEcho file1 file2\n");
                return SUCCESS;
            }
        }
        else
        {
            printf("ERROR: Bad Arguments\n");
        }
        return BAD_ARGS;
    }
    return SKIP;
}

int read_image(const char *filename, Image *image)
{

    FILE *file = fopen(filename, "r");
    if (!file) // if file doesn't exist return error
    {
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }
    // get first 2 characters which should be magic number
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    image->magicNumberValue = (unsigned short *)image->magicNumber;
    fclose(file);

    // checking against the casted value due to endienness.
    unsigned short *comparison = image->magicNumberValue;
    if (*comparison != MAGIC_NUMBER && *comparison != MAGIC_NUMBEREBU && *comparison != MAGIC_NUMBEREBC)
    { // check magic number
        printf("ERROR: Bad Magic Number (%s)\n", filename);
        return BAD_MAGIC_NUMBER;
    } // check magic number
    return SUCCESS;
}
int readebf(const char *filename, Image *image)
{
    // skip magic number
    FILE *file = fopen(filename, "r");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    // if height and and width too big or too small return error
    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    {
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }
    // creating malloc by using block method
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // if malloc creating fails return erro
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }
    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            unsigned int pixel;
            if (fscanf(file, "%u", &pixel) != 1 || pixel > 31 || pixel < 0)
            { // if data bigger or smaller than whats allowed print error
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }
            // store the data in the array
            image->data[j][k] = pixel;
        }
    }
    // checking to see if we are at the end of the file
    unsigned int checkend = fscanf(file, "%u", &checkend);
    if (checkend != EOF)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }
    fclose(file);
    return SUCCESS;
}

int readebu(const char *filename, Image *image)
{ // reading this way if ebu
    FILE *file = fopen(filename, "rb");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);

    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    { // checking header dimensions
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }

    // allocating memory for data in the file
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // if malloc fails to be allocated return error
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }

    unsigned char ignore; // ignore the binary value for newline
    fread(&ignore, sizeof(unsigned char), 1, file);

    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            unsigned char pixel; // declare a variable to store the pixel value
            // read in the next pixel value from the file
            int reader = fread(&pixel, sizeof(unsigned char), 1, file);
            if (reader != 1)
            {
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }

            // check that the pixel value is within the specified range
            if (pixel > 31 || pixel < 0)
            {
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }

            // store the pixel value in the image data array
            image->data[j][k] = pixel;
        }
    }
    unsigned char pixel;
    if (fread(&pixel, 1, 1, file) == 1)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }
    fclose(file);
    return 0;
}

int readebc(const char *filename, Image *image)
{ // reading this way if ebu
    FILE *file = fopen(filename, "rb");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    // checkig to make sure that the data is not outside of allowed width and height
    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    {
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }
    // creating 2d malloc
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // cehckinng malloc not empty
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }

    unsigned char ignore; // ignore the binary value for newline
    fread(&ignore, sizeof(unsigned char), 1, file);

    unsigned int size = (image->width * image->height * 5) / 8; // Calculate the size of the array
    if ((image->width * image->height * 5) % 8 != 0)
    {              // Check if there is a remainder
        size += 1; // Add 1 to the size if there is a remainder
    }

    // Store the current position in the file
    unsigned int pos = ftell(file);

    // Move the file pointer to the end of the file to determine its size
    fseek(file, 0L, SEEK_END);
    unsigned int sizebin = ftell(file);

    // Move the file pointer back to the original position
    fseek(file, pos, SEEK_SET);

    // Validate the size of the binary data
    unsigned char pixel[size];
    unsigned int comp = sizebin - size - pos;
    if (comp != 0)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Read the binary pixel data from the file
    int reader = fread(pixel, sizeof(unsigned char), size, file);
    if (reader != size)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Convert the binary pixel data to integer values
    unsigned int bits = 0;
    unsigned int bit_position = 0;
    unsigned int num = 0;

    // Iterate through the binary pixel data
    for (int j = 0; j < size; j++)
    {
        for (int k = 7; k >= 0; k--)
        {
            // Extract the bit from the current pixel byte
            unsigned int bit = ((unsigned int)pixel[j] >> k) & 0x01;

            // Append the bit to the bits variable
            bits <<= 1;
            bits |= bit;
            bit_position++;

            // When 5 bits are accumulated, store the value in the image data
            if (bit_position == 5)
            {
                num++;
                image->data[(num - 1) / image->width][(num - 1) % image->width] = bits;
                bits = 0;
                bit_position = 0;
            }
        }
    }

    // Check if there are any remaining bits that haven't been stored
    if (bits > 0)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Close the file
    fclose(file);

    // Return success code
    return 0;
}

int writefileebu(char *argv, Image *image)
{
    FILE *file = fopen(argv, "wb");
    if (file == NULL)
    { // validate output file
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", argv);
        return BAD_FILE;
    } // validate output file

    // write the header data in one block
    int check = fprintf(file, "eu\n%d %d\n", image->height, image->width);
    // and use the return from fprintf to check that we wrote.
    if (check == 0)
    { // check write
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    } // check write

    // iterate though the array and print out pixel values
    for (int current = 0; current < image->height; current++)
    { // writing out
        for (int current2 = 0; current2 < image->width; current2++)
        {
            unsigned char buffer = (unsigned char)(image->data[current][current2] & 0xFF);
            check = fwrite(&buffer, sizeof(unsigned char), 1, file);
            if (check == 0)
            { // check write
                fclose(file);
                free(image->datablock);
                free(image->data);
                printf("ERROR: Bad Output\n");
                return BAD_OUTPUT;
            } // check write
        }

    } // writing out
    fclose(file);
    return SUCCESS;
}

int diff_identical(Image *image1, Image *image2)
{

    // checking magic numbers
    if (image1->magicNumberValue - image2->magicNumberValue == 0)
    { // free and exit
        free(image1->datablock);
        free(image1->data);
        free(image2->datablock);
        free(image2->data);
        printf("DIFFERENT\n");
        return DIFFERENT;
    } // free and exit

    // check dimensions
    if ((image1->height != image2->height) || (image1->width != image2->width))
    { // free and exit
        free(image1->datablock);
        free(image1->data);
        free(image2->datablock);
        free(image2->data);
        printf("DIFFERENT\n");
        return DIFFERENT;
    } // free and exit

    // and check the pixel values
    for (int n = 0; n < image1->height; n++)
    {
        for (int t = 0; t < image1->width; t++)
        {
            if (image1->data[n][t] != image2->data[n][t])
            { // free and exit
                free(image1->datablock);
                free(image1->data);
                free(image2->datablock);
                free(image2->data);
                printf("DIFFERENT\n");
                return DIFFERENT;
            } // free and exit
        }
    }
    free(image1->datablock);
    free(image1->data);
    free(image2->datablock);
    free(image2->data);
    printf("IDENTICAL\n");
    return SUCCESS;
}

int writefile(char *argv, Image *image)
{
    // open the output file in write mode
    // validate that the file has been opened correctly
    FILE *file = fopen(argv, "w");
    if (file == NULL)
    { // validate output file
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", argv);
        return BAD_FILE;
    } // validate output file

    // write the header data in one block
    int check = fprintf(file, "eb\n%d %d\n", image->height, image->width);
    // and use the return from fprintf to check that we wrote.
    if (check == 0)
    { // check write
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    } // check write

    // iterate though the array and print out pixel values
    for (int current = 0; current < image->height; current++)
    {
        // writing out
        for (int current2 = 0; current2 < image->width; current2++)
        {
            check = fprintf(file, "%u%s", image->data[current][current2], (current2 != image->width - 1) ? " " : "");
            if (check == 0)
            {
                // check write
                fclose(file);
                free(image->datablock);
                free(image->data);
                printf("ERROR: Bad Output\n");
                return BAD_OUTPUT;
            } // check write
        }
        if (current != image->height - 1)
        {
            fprintf(file, "\n");
        }
    }
    fclose(file);
    return SUCCESS;
}

int writefileebc(char *filename, Image *image)
{
    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "ec\n%d %d\n", image->height, image->width);
    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    unsigned int size = (image->width * image->height * 5) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((image->width * image->height * 5) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                             // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    // Iterate through the image data
    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            // Convert each pixel value into 5 bits and store them in the bits variable
            for (int t = 0; t < 5; t++)
            {
                // Extract the bit from the current pixel value
                unsigned int bit = (image->data[j][k] >> (4 - t)) & 0x01;

                // Append the bit to the bits variable
                bits <<= 1;
                bits |= bit;
                bit_position++;

                // When 8 bits are accumulated, store the value in the pixel buffer
                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }

    // If there are remaining bits, add padding bits and store in the pixel buffer
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }

    // Write the pixel buffer to the file
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        // If the write operation failed, close the file, free allocated memory, and return an error code
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    // Close the file
    fclose(file);

    // Return success code
    return SUCCESS;
}
