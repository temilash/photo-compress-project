
int validate_args(int argc, const char *filename);

int read_image(const char *filename, Image *image);

int read_imageebu(const char *filename, Image *image);

int readebf(const char *filename, Image *image);

int readebu(const char *filename, Image *image);

int readebc(const char *filename, Image *image);

int read_imageebc(const char *filename, Image *image);

int writefile(char *argv, Image *image);

int diff_identical(Image *image1, Image *image2);

int writefileebu(char *argv, Image *image);

int writefileebc(char *argv, Image *image);

void blockcompression(Image *image);

int ebcBlockwrite(char *filename, Image *image);

void blockuncompress(Image *image);

int readebccomp (const char *filename, Image *image);

void randomblox(Image *image, unsigned int seed,int r32_r128);

int writefileebcr32(char *filename, Image *image,char type);

int writefileebcr32uncompressed(char *filename, Image *image);

void randombloxdecomp(Image *image);

int writefileebcr128compressed(char *filename, Image *image, char type);

int writefileebcr128uncompressed(char *filename, Image *image);

int validate_args_128_32(int argc, const char *filename);