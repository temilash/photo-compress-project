#include "images.h"
#include "shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define BAD_ARGS 1
#define BAD_FILE 2
#define BAD_MAGIC_NUMBER 3
#define BAD_DIM 4
#define BAD_MALLOC 5
#define BAD_DATA 6
#define BAD_OUTPUT 7
#define MAGIC_NUMBER 0x6265
#define MAGIC_NUMBEREBU 0x7565
#define MAGIC_NUMBEREBC 0x6365
#define MAX_DIMENSION 262144
#define MIN_DIMENSION 1
#define SKIP 411
#define DIFFERENT 222

int validate_args(int argc, const char *filename)
{
    if (argc != 3)
    {
        if (argc == 1)
        { // if arguments are 1 then print one of options available depending on the type of file
            if (strcmp(filename, "./ebfComp") == 0)
            {
                printf("Usage: ebfComp file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebuComp") == 0)
            {
                printf("Usage: ebuComp file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebuEcho") == 0)
            {
                printf("Usage: ebuEcho file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebfEcho") == 0)
            {
                printf("Usage: ebfEcho file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebf2ebu") == 0)
            {
                printf("Usage: ebf2ebu file1 file2\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebu2ebf") == 0)
            {
                printf("Usage: ebu2ebf file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcComp") == 0)
            {
                printf("Usage: ebcComp file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebc2ebu") == 0)
            {
                printf("Usage: ebc2ebu file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebu2ebc") == 0)
            {
                printf("Usage: ebu2ebc file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcEcho") == 0)
            {
                printf("Usage: ebcEcho file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcBlock") == 0)
            {
                printf("Usage: ebcBlock file1 file2\n");
                return SUCCESS;
            }
            if (strcmp(filename, "./ebcUnblock") == 0)
            {
                printf("Usage: ebcUnblock file1 file2\n");
                return SUCCESS;
            }
        }
        else
        {
            printf("ERROR: Bad Arguments\n");
        }
        return BAD_ARGS;
    }
    return SKIP;
}

int read_image(const char *filename, Image *image)
{

    FILE *file = fopen(filename, "r");
    if (!file) // if file doesn't exist return error
    {
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }
    // get first 2 characters which should be magic number
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    image->magicNumberValue = (unsigned short *)image->magicNumber;
    fclose(file);

    // checking against the casted value due to endienness.
    unsigned short *comparison = image->magicNumberValue;
    if (*comparison != MAGIC_NUMBER && *comparison != MAGIC_NUMBEREBU && *comparison != MAGIC_NUMBEREBC)
    { // check magic number
        printf("ERROR: Bad Magic Number (%s)\n", filename);
        return BAD_MAGIC_NUMBER;
    } // check magic number
    return SUCCESS;
}
int readebf(const char *filename, Image *image)
{
    // skip magic number
    FILE *file = fopen(filename, "r");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    // if height and and width too big or too small return error
    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    {
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }
    // creating malloc by using block method
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // if malloc creating fails return erro
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }
    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            unsigned int pixel;
            if (fscanf(file, "%u", &pixel) != 1 || pixel > 31 || pixel < 0)
            { // if data bigger or smaller than whats allowed print error
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }
            // store the data in the array
            image->data[j][k] = pixel;
        }
    }
    // checking to see if we are at the end of the file
    unsigned int checkend = fscanf(file, "%u", &checkend);
    if (checkend != EOF)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }
    fclose(file);
    return SUCCESS;
}

int readebu(const char *filename, Image *image)
{ // reading this way if ebu
    FILE *file = fopen(filename, "rb");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);

    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    { // checking header dimensions
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }

    // allocating memory for data in the file
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // if malloc fails to be allocated return error
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }

    unsigned char ignore; // ignore the binary value for newline
    fread(&ignore, sizeof(unsigned char), 1, file);

    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            unsigned char pixel; // declare a variable to store the pixel value
            // read in the next pixel value from the file
            int reader = fread(&pixel, sizeof(unsigned char), 1, file);
            if (reader != 1)
            {
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }

            // check that the pixel value is within the specified range
            if (pixel > 31 || pixel < 0)
            {
                printf("ERROR: Bad Data (%s)\n", filename);
                free(image->datablock);
                free(image->data);
                fclose(file);
                return BAD_DATA;
            }

            // store the pixel value in the image data array
            image->data[j][k] = pixel;
        }
    }
    unsigned char pixel;
    if (fread(&pixel, 1, 1, file) == 1)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }
    fclose(file);
    return 0;
}

int readebc(const char *filename, Image *image)
{ // reading this way if ebu
    FILE *file = fopen(filename, "rb");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    // checkig to make sure that the data is not outside of allowed width and height
    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    {
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }
    // creating 2d malloc
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // cehckinng malloc not empty
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }

    unsigned char ignore; // ignore the binary value for newline
    fread(&ignore, sizeof(unsigned char), 1, file);

    unsigned int size = (image->width * image->height * 5) / 8; // Calculate the size of the array
    if ((image->width * image->height * 5) % 8 != 0)
    {              // Check if there is a remainder
        size += 1; // Add 1 to the size if there is a remainder
    }

    // Store the current position in the file
    unsigned int pos = ftell(file);

    // Move the file pointer to the end of the file to determine its size
    fseek(file, 0L, SEEK_END);
    unsigned int sizebin = ftell(file);

    // Move the file pointer back to the original position
    fseek(file, pos, SEEK_SET);

    // Validate the size of the binary data
    unsigned char pixel[size];
    unsigned int comp = sizebin - size - pos;
    if (comp != 0)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Read the binary pixel data from the file
    int reader = fread(pixel, sizeof(unsigned char), size, file);
    if (reader != size)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Convert the binary pixel data to integer values
    unsigned int bits = 0;
    unsigned int bit_position = 0;
    unsigned int num = 0;

    // Iterate through the binary pixel data
    for (int j = 0; j < size; j++)
    {
        for (int k = 7; k >= 0; k--)
        {
            // Extract the bit from the current pixel byte
            unsigned int bit = ((unsigned int)pixel[j] >> k) & 0x01;

            // Append the bit to the bits variable
            bits <<= 1;
            bits |= bit;
            bit_position++;

            // When 5 bits are accumulated, store the value in the image data
            if (bit_position == 5)
            {
                num++;
                image->data[(num - 1) / image->width][(num - 1) % image->width] = bits;
                bits = 0;
                bit_position = 0;
            }
        }
    }

    // Check if there are any remaining bits that haven't been stored
    if (bits > 0)
    {
        // Print an error message, free allocated memory, close the file, and return error code
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    // Close the file
    fclose(file);

    // Return success code
    return 0;
}

int writefileebu(char *argv, Image *image)
{
    FILE *file = fopen(argv, "wb");
    if (file == NULL)
    { // validate output file
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", argv);
        return BAD_FILE;
    } // validate output file

    // write the header data in one block
    int check = fprintf(file, "eu\n%d %d\n", image->height, image->width);
    // and use the return from fprintf to check that we wrote.
    if (check == 0)
    { // check write
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    } // check write

    // iterate though the array and print out pixel values
    for (int current = 0; current < image->height; current++)
    { // writing out
        for (int current2 = 0; current2 < image->width; current2++)
        {
            unsigned char buffer = (unsigned char)(image->data[current][current2] & 0xFF);
            check = fwrite(&buffer, sizeof(unsigned char), 1, file);
            if (check == 0)
            { // check write
                fclose(file);
                free(image->datablock);
                free(image->data);
                printf("ERROR: Bad Output\n");
                return BAD_OUTPUT;
            } // check write
        }

    } // writing out
    fclose(file);
    return SUCCESS;
}

int diff_identical(Image *image1, Image *image2)
{

    // checking magic numbers
    if (image1->magicNumberValue - image2->magicNumberValue == 0)
    { // free and exit
        free(image1->datablock);
        free(image1->data);
        free(image2->datablock);
        free(image2->data);
        printf("DIFFERENT\n");
        return DIFFERENT;
    } // free and exit

    // check dimensions
    if ((image1->height != image2->height) || (image1->width != image2->width))
    { // free and exit
        free(image1->datablock);
        free(image1->data);
        free(image2->datablock);
        free(image2->data);
        printf("DIFFERENT\n");
        return DIFFERENT;
    } // free and exit

    // and check the pixel values
    for (int n = 0; n < image1->height; n++)
    {
        for (int t = 0; t < image1->width; t++)
        {
            if (image1->data[n][t] != image2->data[n][t])
            { // free and exit
                free(image1->datablock);
                free(image1->data);
                free(image2->datablock);
                free(image2->data);
                printf("DIFFERENT\n");
                return DIFFERENT;
            } // free and exit
        }
    }
    free(image1->datablock);
    free(image1->data);
    free(image2->datablock);
    free(image2->data);
    printf("IDENTICAL\n");
    return SUCCESS;
}

int writefile(char *argv, Image *image)
{
    // open the output file in write mode
    // validate that the file has been opened correctly
    FILE *file = fopen(argv, "w");
    if (file == NULL)
    { // validate output file
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", argv);
        return BAD_FILE;
    } // validate output file

    // write the header data in one block
    int check = fprintf(file, "eb\n%d %d\n", image->height, image->width);
    // and use the return from fprintf to check that we wrote.
    if (check == 0)
    { // check write
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    } // check write

    // iterate though the array and print out pixel values
    for (int current = 0; current < image->height; current++)
    {
        // writing out
        for (int current2 = 0; current2 < image->width; current2++)
        {
            check = fprintf(file, "%u%s", image->data[current][current2], (current2 != image->width - 1) ? " " : "");
            if (check == 0)
            {
                // check write
                fclose(file);
                free(image->datablock);
                free(image->data);
                printf("ERROR: Bad Output\n");
                return BAD_OUTPUT;
            } // check write
        }
        if (current != image->height - 1)
        {
            fprintf(file, "\n");
        }
    }
    fclose(file);
    return SUCCESS;
}

int writefileebc(char *filename, Image *image)
{
    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "ec\n%d %d\n", image->height, image->width);
    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    unsigned int size = (image->width * image->height * 5) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((image->width * image->height * 5) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                             // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    // Iterate through the image data
    for (int j = 0; j < image->height; j++)
    {
        for (int k = 0; k < image->width; k++)
        {
            // Convert each pixel value into 5 bits and store them in the bits variable
            for (int t = 0; t < 5; t++)
            {
                // Extract the bit from the current pixel value
                unsigned int bit = (image->data[j][k] >> (4 - t)) & 0x01;

                // Append the bit to the bits variable
                bits <<= 1;
                bits |= bit;
                bit_position++;

                // When 8 bits are accumulated, store the value in the pixel buffer
                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }

    // If there are remaining bits, add padding bits and store in the pixel buffer
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }

    // Write the pixel buffer to the file
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        // If the write operation failed, close the file, free allocated memory, and return an error code
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    // Close the file
    fclose(file);

    // Return success code
    return SUCCESS;
}

void blockcompression(Image *image)
{

    // finding out the number of 3x3 blocks

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    // making an array for blocks

    unsigned int arrayblock[blocktotalheight][blocktotalwidth];
    // making array for number of numbers in block
    unsigned int arrayblocktotal[blocktotalheight][blocktotalwidth];

    memset(arrayblock, 0, sizeof(arrayblock));
    memset(arrayblocktotal, 0, sizeof(arrayblocktotal));

    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            unsigned int datastore = image->data[i][j];
            // locate the block it should be stored in and add to it
            arrayblock[i / 3][j / 3] = datastore + arrayblock[i / 3][j / 3];
            // increase numbers of numbers in block by 1
            arrayblocktotal[i / 3][j / 3] += 1;
        }
    }

    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            // Calculating the mean value from the values in the block
            float tempint1 = (float)arrayblock[i][k];
            float tempint2 = (float)arrayblocktotal[i][k];
            arrayblock[i][k] = (unsigned int)((tempint1 / tempint2) + 0.5);
        }
    }

    free(image->datablock);
    free(image->data);

    image->data = (unsigned int **)malloc(blocktotalheight * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(blocktotalwidth * blocktotalheight * sizeof(unsigned int));
    for (int i = 0; i < blocktotalheight; i++)
    {
        image->data[i] = image->datablock + i * blocktotalwidth;
    }

    unsigned int total = 0;

    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            image->data[i][k] = arrayblock[i][k];
            total++;
        }
    }
}

int ebcBlockwrite(char *filename, Image *image)
{

    // open the output file in write mode
    // validate that the file has been opened correctly
    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    { // validate output file
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    } // validate output file

    // write the header data in one block
    int check = fprintf(file, "ec\n%d %d\n", image->height, image->width);
    // and use the return from fprintf to check that we wrote.
    if (check == 0)
    { // check write
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    } // check write

    // finding out the number of 3x3 blocks

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    unsigned int size = (blocktotalwidth * blocktotalheight * 5) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((blocktotalwidth * blocktotalheight * 5) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                                   // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    // Iterate through the image data
    for (int j = 0; j < blocktotalheight; j++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            // Convert each pixel value into 5 bits and store them in the bits variable
            for (int t = 0; t < 5; t++)
            {
                // Extract the bit from the current pixel value
                unsigned int bit = (image->data[j][k] >> (4 - t)) & 0x01;

                // Append the bit to the bits variable
                bits <<= 1;
                bits |= bit;
                bit_position++;

                // When 8 bits are accumulated, store the value in the pixel buffer
                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }

    // If there are remaining bits, add padding bits and store in the pixel buffer
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }

    // Write the pixel buffer to the file
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        // If the write operation failed, close the file, free allocated memory, and return an error code
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    // Close the file
    fclose(file);

    // Return success code
    return SUCCESS;
}

void blockuncompress(Image *image)
{

    // finding out the number of 3x3 blocks

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    // making an array for blocks
    unsigned int arrayblock[blocktotalheight][blocktotalwidth];

    memset(arrayblock, 0, sizeof(arrayblock));

    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            // saving compressed values to temporary array
            arrayblock[i][k] = image->data[i][k];
        }
    }

    free(image->data);
    free(image->datablock);

    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    unsigned int toal = 0;
    for (int i = 0; i < image->height; i++)
    {
        for (int k = 0; k < image->width; k++)
        {
            // Calculate the block coordinates
            int blockRow = i / 3;
            int blockCol = k / 3;

            // Update values in the array
            image->data[i][k] = arrayblock[blockRow][blockCol];
            toal++;
        }
    }
}

int readebccomp(const char *filename, Image *image)
{ // reading this way if ebu
    FILE *file = fopen(filename, "rb");
    image->magicNumber[0] = getc(file);
    image->magicNumber[1] = getc(file);
    // checkig to make sure that the data is not outside of allowed width and height
    if (fscanf(file, "%d %d", &image->height, &image->width) != 2 || image->height < MIN_DIMENSION || image->width < MIN_DIMENSION || image->height > MAX_DIMENSION || image->width > MAX_DIMENSION)
    {
        printf("ERROR: Bad Dimensions (%s)\n", filename);
        fclose(file);
        return BAD_DIM;
    }
    // creating 2d malloc
    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    image->data = (unsigned int **)malloc(blocktotalheight * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(blocktotalwidth * blocktotalheight * sizeof(unsigned int));
    for (int i = 0; i < blocktotalheight; i++)
    {
        image->data[i] = image->datablock + i * blocktotalwidth;
    }

    if (image->data == NULL || image->datablock == NULL)
    { // cehckinng malloc not empty
        printf("ERROR: Image Malloc Failed\n");
        fclose(file);
        return BAD_MALLOC;
    }

    unsigned char ignore; // ignore the binary value for newline
    fread(&ignore, sizeof(unsigned char), 1, file);

    unsigned int size = (blocktotalwidth * blocktotalwidth * 5) / 8; // Calculate the size of the array
    if ((blocktotalwidth * blocktotalheight * 5) % 8 != 0)
    {              // Check if there is a remainder
        size += 1; // Add 1 to the size if there is a remainder
    }

    unsigned int pos = ftell(file);
    fseek(file, 0L, SEEK_END);
    unsigned int sizebin = ftell(file);
    fseek(file, pos, SEEK_SET);

    unsigned char pixel[size];
    unsigned int comp = sizebin - size - pos;
    if (comp != 0)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    int reader = fread(pixel, sizeof(unsigned char), size, file);
    if (reader != size)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    unsigned int bits = 0;
    unsigned int bit_position = 0;
    unsigned int num = 0;

    for (int j = 0; j < size; j++)
    {

        for (int k = 7; k >= 0; k--)
        {

            unsigned int bit = ((unsigned int)pixel[j] >> k) & 0x01;

            bits <<= 1;
            bits |= bit;
            bit_position++;

            if (bit_position == 5)
            {
                num++;
                image->data[(num - 1) / blocktotalwidth][(num - 1) % blocktotalwidth] = bits;
                bits = 0;
                bit_position = 0;
            }
        }
    }
    if (bits > 0)
    {
        printf("ERROR: Bad Data (%s)\n", filename);
        free(image->datablock);
        free(image->data);
        fclose(file);
        return BAD_DATA;
    }

    fclose(file);
    return 0;
}

void randomblox(Image *image, unsigned int seed, int r32_r128)
{
    //setting seeding to argument passed in by user
    srand(seed);
    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    if (blocktotalheight * blocktotalwidth < 32)
    {
        return;
    }

    unsigned int min_blocks = 0;

    //finding out number of paradigm blocks
    if(blocktotalheight*blocktotalwidth<32 && r32_r128 == 32){
        min_blocks =  blocktotalheight*blocktotalwidth;
    }
    else if(blocktotalheight*blocktotalwidth>=32 && r32_r128 == 32){
        min_blocks = 32;
    }
    else if(blocktotalheight*blocktotalwidth < 128 && r32_r128 == 128){
        min_blocks =  blocktotalheight*blocktotalwidth;
    }
    else if(blocktotalheight*blocktotalwidth >= 128 && r32_r128 == 128){
        min_blocks = 128;
    }

    unsigned int pblockcount[128];
    int blockCount = 0;
    unsigned int dx[128];
    unsigned int dy[128];
    memset(pblockcount, 0, sizeof(pblockcount));
    memset(dx, 0, sizeof(dx));
    memset(dy, 0, sizeof(dy));

    //looping through till we get enough paradigm blocks
    while (blockCount < min_blocks)
    {
        unsigned int xblock = rand() % blocktotalwidth;
        unsigned int yblock = rand() % blocktotalheight;

        int overlap = 0;
        //cehcking for overlap between any paradigm blocks
        for (int i = 0; i < blockCount; i++)
        {
            int xpos = dx[i];
            int ypos = dy[i];
            if (xpos == xblock && ypos == yblock)
            {
                overlap = 1;
            }
        }
        //if there is no overlap add the paradigm block to array
        if (overlap == 0)
        {
            dx[blockCount] = xblock;
            dy[blockCount] = yblock;

            for (int i = 0; i < 3; i++)
            {
                for (int t = 0; t < 3; t++)
                {
                    int imageX = (xblock * 3) + t;
                    int imageY = (yblock * 3) + i;

                    // Check if the indices are within the bounds of image->data
                    if (imageX < image->width && imageY < image->height)
                    {
                        image->pblocks[blockCount][i][t] = image->data[imageY][imageX];
                        pblockcount[blockCount]++;
                    }
                    else
                    {
                        // Handle out-of-bounds case (e.g., assign a default or ignore)
                        // For example, you can assign a default value of 0:
                        image->pblocks[blockCount][i][t] = 0;
                    }
                }
            }

            blockCount++;
        }
    }
    unsigned int totalsize[128];
    // finding the average size of each block for calculations
    for (int i = 0; i < min_blocks; i++)
    {
        unsigned int total = 0;

        for(int t = 0; t<3; t++){

            for(int p = 0; p<3; p++){
                total = image->pblocks[i][t][p] + total;
            }
        }
        
        float tempint1 = (float)total;
        totalsize[i] = (unsigned int)((tempint1 / 9.0) + 0.5);
    }

    // making an array for blocks

    unsigned int arrayblock[blocktotalheight][blocktotalwidth];
    unsigned int arraypblock[blocktotalheight][blocktotalwidth];
    // making array for number of numbers in block
    unsigned int arrayblocktotal[blocktotalheight][blocktotalwidth];

    memset(arrayblock, 0, sizeof(arrayblock));
    memset(arrayblock, 0, sizeof(arraypblock));
    memset(arrayblocktotal, 0, sizeof(arrayblocktotal));

    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            unsigned int datastore = image->data[i][j];
            // locate the block it should be stored in and add to it
            arrayblock[i / 3][j / 3] = datastore + arrayblock[i / 3][j / 3];
            // increase numbers of numbers in block by 1
            arrayblocktotal[i / 3][j / 3] += 1;
        }
    }

    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            // Calculating the mean value from the values in the block
            float tempint1 = (float)arrayblock[i][k];
            float tempint2 = (float)arrayblocktotal[i][k];
            arrayblock[i][k] = (unsigned int)((tempint1 / tempint2) + 0.5);
        }
    }

    for (int k = 0; k < blocktotalheight; k++)
    {
        for (int t = 0; t < blocktotalwidth; t++)
        {
            unsigned int closestValue = 0; // Assume the first value is the closest initially

            // Calculate the difference between arrayblock[k][t] and each value in totalsize
            for (int z = 1; z < min_blocks; z++)
            { // Start from index 1 since we already assumed index 0 as closest
                unsigned int diff = abs(arrayblock[k][t] - totalsize[z]);

                // Check if the current value is closer than the previously found closestValue
                if (diff < abs(arrayblock[k][t] - totalsize[closestValue]))
                {
                    closestValue = z;
                }
            }

            // Store the closest value in arraypblock
            arraypblock[k][t] = closestValue;
        }
    }

    // store the values in image->data and then print off the data
    free(image->datablock);
    free(image->data);

    image->data = (unsigned int **)malloc(blocktotalheight * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(blocktotalwidth * blocktotalheight * sizeof(unsigned int));
    for (int i = 0; i < blocktotalheight; i++)
    {
        image->data[i] = image->datablock + i * blocktotalwidth;
    }

    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int k = 0; k < blocktotalwidth; k++)
        {
            image->data[i][k] = arraypblock[i][k];
        }
    }
}

int writefileebcr32(char *filename, Image *image, char type)
{

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "E%c\n%d %d\n", type, image->height, image->width);

    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }
    if(type == '5'){

        check = fprintf(file, "32\n");

        // Check the return value of fprintf to ensure successful write
        if (check == 0)
        {
            fclose(file);
            free(image->datablock);
            free(image->data);
            printf("ERROR: Bad Output\n");
            return BAD_OUTPUT;
        }
    }

    unsigned int size = (blocktotalwidth * blocktotalheight * 5) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((blocktotalwidth * blocktotalheight * 5) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                                   // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    for (int j = 0; j < blocktotalheight; j++)
    {

        for (int k = 0; k < blocktotalwidth; k++)
        {

            for (int t = 0; t < 5; t++)
            {

                unsigned int bit = (image->data[j][k] >> (4 - t)) & 0x01;
                bits <<= 1;
                bits |= bit;
                bit_position++;

                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    fclose(file);
    return SUCCESS;
}

int writefileebcr32uncompressed(char *filename, Image *image)
{

    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "E7\n%d %d\n", image->height, image->width);

    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    

    unsigned int size = (image->width * image->height * 5) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((image->width * image->height * 5) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                             // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    for (int j = 0; j < image->height; j++)
    {

        for (int k = 0; k < image->width; k++)
        {

            for (int t = 0; t < 5; t++)
            {

                unsigned int bit = (image->data[j][k] >> (4 - t)) & 0x01;
                bits <<= 1;
                bits |= bit;
                bit_position++;

                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    fclose(file);
    return SUCCESS;
}

void randombloxdecomp(Image *image)
{
    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    unsigned int temparray[blocktotalheight][blocktotalwidth];
    for (int i = 0; i < blocktotalheight; i++)
    {
        for (int j = 0; j < blocktotalwidth; j++)
        {
            temparray[i][j] = image->data[i][j];
        }
    }

    free(image->data);
    free(image->datablock);
    //recreating the image array to store more values not compressed values
    image->data = (unsigned int **)malloc(image->height * sizeof(unsigned int *));
    image->datablock = (unsigned int *)malloc(image->width * image->height * sizeof(unsigned int));
    for (int i = 0; i < image->height; i++)
    {
        image->data[i] = image->datablock + i * image->width;
    }

    for (int i = 0; i < image->height; i++)
    {
        for (int j = 0; j < image->width; j++)
        {
            unsigned int yblock = i/3;
            unsigned int xblock = j/3;
            image->data[i][j] = image->pblocks[(temparray[yblock][xblock])][i%3][j%3];
        }
    }
}

int writefileebcr128compressed(char *filename, Image *image, char type)
{

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "E%c\n%d %d\n128\n", type, image->height, image->width);

    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }


    unsigned int size = (blocktotalwidth * blocktotalheight * 7) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((blocktotalwidth * blocktotalheight * 7) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                                   // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    for (int j = 0; j < blocktotalheight; j++)
    {

        for (int k = 0; k < blocktotalwidth; k++)
        {

            for (int t = 0; t < 7; t++)
            {
                
                unsigned int bit = (image->data[j][k] >> (6 - t)) & 0x01;
                bits <<= 1;
                bits |= bit;
                bit_position++;

                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    fclose(file);
    return SUCCESS;
}

int writefileebcr128uncompressed(char *filename, Image *image)
{

    unsigned int blocktotalwidth = image->width;
    if (blocktotalwidth % 3 != 0)
    {
        blocktotalwidth = (blocktotalwidth / 3 + 1);
    }
    else
    {
        blocktotalwidth /= 3;
    }

    unsigned int blocktotalheight = image->height;
    if (blocktotalheight % 3 != 0)
    {
        blocktotalheight = (blocktotalheight / 3 + 1);
    }
    else
    {
        blocktotalheight /= 3;
    }

    FILE *file = fopen(filename, "wb");
    if (file == NULL)
    {
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad File Name (%s)\n", filename);
        return BAD_FILE;
    }

    // Write the header data in one block
    int check = fprintf(file, "E7\n%d %d\n128\n", image->height, image->width);

    // Check the return value of fprintf to ensure successful write
    if (check == 0)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }


    unsigned int size = (image->width * image->height * 7) / 8;                     // Calculate the size of the array
    unsigned int padding_bits = (8 - ((image->width * image->height * 7) % 8)) % 8; // Calculate the number of padding bits needed
    size += (padding_bits > 0) ? 1 : 0;                                                   // Add an extra byte if padding bits are needed

    unsigned char pixel[size];
    memset(pixel, 0, size); // Set all bytes to zero

    unsigned int num = 0;
    unsigned int bits = 0;
    unsigned int bit_position = 0;

    for (int j = 0; j < image->height; j++)
    {

        for (int k = 0; k < image->width; k++)
        {

            for (int t = 0; t < 7; t++)
            {
                
                unsigned int bit = (image->data[j][k] >> (6 - t)) & 0x01;
                bits <<= 1;
                bits |= bit;
                bit_position++;

                if (bit_position == 8)
                {
                    pixel[num] = bits;
                    num++;
                    bits = 0;
                    bit = 0;
                    bit_position = 0;
                }
            }
        }
    }
    if (bits != 0)
    {
        pixel[num] = bits << (8 - bit_position); // Add padding bits
    }
    check = fwrite(&pixel, sizeof(unsigned char), size, file);
    if (check != size)
    {
        fclose(file);
        free(image->datablock);
        free(image->data);
        printf("ERROR: Bad Output\n");
        return BAD_OUTPUT;
    }

    fclose(file);
    return SUCCESS;
}

int validate_args_128_32(int argc, const char *filename)
{
    if (argc != 4)
    {
        if (argc == 1)
        { // if arguments are 1 then print one of options available depending on the type of file
            if (strcmp(filename, "./ebcR32") == 0)
            {
                printf("Usage: ebfComp file1 file2 seed\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebcU32") == 0)
            {
                printf("Usage: ebuComp file1 file2 seed\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebcR128") == 0)
            {
                printf("Usage: ebuEcho file1 file2 seed\n");
                return SUCCESS;
            }
            else if (strcmp(filename, "./ebcU128") == 0)
            {
                printf("Usage: ebfEcho file1 file2 seed\n");
                return SUCCESS;
            }
            
        }
        else
        {
            printf("ERROR: Bad Arguments\n");
        }
        return BAD_ARGS;
    }
    return SKIP;
}
