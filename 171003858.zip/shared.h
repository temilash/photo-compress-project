int validate_args(int argc, const char *filename);

int read_image(const char *filename, Image *image);

int read_imageebu(const char *filename, Image *image);

int readebf(const char *filename, Image *image);

int readebu(const char *filename, Image *image);

int readebc(const char *filename, Image *image);

int read_imageebc(const char *filename, Image *image);

int writefile(char *argv, Image *image);

int diff_identical(Image *image1, Image *image2);

int writefileebu(char *argv, Image *image);

int writefileebc(char *argv, Image *image);