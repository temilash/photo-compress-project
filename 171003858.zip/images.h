typedef struct Image {
    int width;
    int height;
    unsigned int **data;
    unsigned int *datablock;
    unsigned char magicNumber[2];
    unsigned short *magicNumberValue;
} Image;