#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define BAD_ARGS 1
#define BAD_FILE 2
#define BAD_MAGIC_NUMBER 3
#define BAD_DIM 4
#define BAD_MALLOC 5
#define BAD_DATA 6
#define BAD_OUTPUT 7
#define MAGIC_NUMBER 0x6265
#define MAGIC_NUMBEREBU 0x7565
#define MAGIC_NUMBEREBC 0x6365
#define MAX_DIMENSION 262144
#define MIN_DIMENSION 1
#define SKIP 411
#define DIFFERENT 222

#include "images.h"
#include "shared.h"

int main(int argc, char **argv)
{

    // validate that user has enter 2 arguments (plus the executable name)
    int validation_result = validate_args(argc, argv[0]);
    if (validation_result != SKIP)
    {
        return validation_result;
    }

    // read image1
    Image image1;
    int read_result1 = read_imageebu(argv[1], &image1);
    if (read_result1 != SUCCESS)
    {
        return read_result1;
    }

    read_result1 = readebu(argv[1], &image1);
    if (read_result1 != SUCCESS)
    {
        return read_result1;
    }

    int out_results = writefile(argv[2], &image1);
    if (out_results != SUCCESS)
    {
        return out_results;
    }
}